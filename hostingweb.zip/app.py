from flask import Flask, render_template, request, redirect, url_for, session, jsonify
import json
import os
import subprocess
import random
import string
import uuid
from datetime import datetime, timedelta
import sys
import shutil
import threading
import time
import zipfile
import psutil

# YUTA CLOUD HOSTING - Billing System Import
from bohudur_gateway import bohudur

app = Flask(__name__)
app.secret_key = 'yuta-super-secret-key-2026'
app.config['MAX_CONTENT_LENGTH'] = 50 * 1024 * 1024

# ============================================
# Session Configuration - Persistent Login (NEW)
# ============================================
app.config['PERMANENT_SESSION_LIFETIME'] = timedelta(days=30)
app.config['SESSION_PERMANENT'] = True
app.config['SESSION_COOKIE_SECURE'] = False
app.config['SESSION_COOKIE_HTTPONLY'] = True
app.config['SESSION_COOKIE_SAMESITE'] = 'Lax'

USERS_FILE = 'users.json'
BOTS_DIR = 'bots'
CPU_HISTORY = {}
CRASH_COUNT = {}
NET_STATS = {}

# YUTA CLOUD HOSTING Files
SETTINGS_FILE = 'yuta_settings.json'
PACKAGES_FILE = 'yuta_packages.json'
INVOICES_FILE = 'yuta_invoices.json'
FREE_TRIALS_FILE = 'yuta_free_trials.json'

os.makedirs(BOTS_DIR, exist_ok=True)

# ============================================
# YUTA CLOUD HOSTING - Settings & Package Helpers
# ============================================

def load_yuta_settings():
    if not os.path.exists(SETTINGS_FILE):
        default = {
            'site_name': 'YUTA CLOUD HOSTING',
            'bohudur_api_key': '',
            'auto_verify_payment': True,
            'currency': 'BDT',
            'trial_days': 3,
            'trial_enabled': True,
            'allow_free_only_once': True
        }
        save_yuta_settings(default)
        return default
    with open(SETTINGS_FILE, 'r', encoding='utf-8') as f:
        return json.load(f)

def save_yuta_settings(data):
    with open(SETTINGS_FILE, 'w', encoding='utf-8') as f:
        json.dump(data, f, indent=4, ensure_ascii=False)

def load_yuta_packages():
    if not os.path.exists(PACKAGES_FILE):
        default = {
            'free_trial': {
                'id': 'free_trial',
                'name': 'Free Trial',
                'icon': '🎁',
                'price': 0,
                'ram': '512MB',
                'disk': '1GB',
                'cpu_limit': 50,
                'days': 3,
                'server_limit': 1,
                'active': True,
                'is_free': True,
                'features': ['1 Server', '512 MB RAM', '1 GB Disk', '3 Days Validity']
            },
            'starter': {
                'id': 'starter',
                'name': 'Starter',
                'icon': '🚀',
                'price': 299,
                'ram': '1GB',
                'disk': '5GB',
                'cpu_limit': 70,
                'days': 30,
                'server_limit': 3,
                'active': True,
                'features': ['3 Servers', '1 GB RAM', '5 GB Disk', '30 Days Validity']
            },
            'pro': {
                'id': 'pro',
                'name': 'Pro',
                'icon': '⚡',
                'price': 599,
                'ram': '2GB',
                'disk': '10GB',
                'cpu_limit': 90,
                'days': 30,
                'server_limit': 10,
                'active': True,
                'features': ['10 Servers', '2 GB RAM', '10 GB Disk', '30 Days Validity']
            },
            'business': {
                'id': 'business',
                'name': 'Business',
                'icon': '💼',
                'price': 999,
                'ram': '4GB',
                'disk': '20GB',
                'cpu_limit': 100,
                'days': 30,
                'server_limit': 25,
                'active': True,
                'features': ['25 Servers', '4 GB RAM', '20 GB Disk', '30 Days Validity']
            },
            'enterprise': {
                'id': 'enterprise',
                'name': 'Enterprise',
                'icon': '👑',
                'price': 1999,
                'ram': '8GB',
                'disk': '50GB',
                'cpu_limit': 100,
                'days': 365,
                'server_limit': 50,
                'active': True,
                'features': ['50 Servers', '8 GB RAM', '50 GB Disk', '365 Days Validity']
            }
        }
        save_yuta_packages(default)
        return default
    with open(PACKAGES_FILE, 'r', encoding='utf-8') as f:
        return json.load(f)

def save_yuta_packages(data):
    with open(PACKAGES_FILE, 'w', encoding='utf-8') as f:
        json.dump(data, f, indent=4, ensure_ascii=False)

def load_yuta_invoices():
    if not os.path.exists(INVOICES_FILE):
        save_yuta_invoices([])
        return []
    with open(INVOICES_FILE, 'r', encoding='utf-8') as f:
        return json.load(f)

def save_yuta_invoices(data):
    with open(INVOICES_FILE, 'w', encoding='utf-8') as f:
        json.dump(data, f, indent=4, ensure_ascii=False)

def load_yuta_free_trials():
    if not os.path.exists(FREE_TRIALS_FILE):
        save_yuta_free_trials({})
        return {}
    with open(FREE_TRIALS_FILE, 'r', encoding='utf-8') as f:
        return json.load(f)

def save_yuta_free_trials(data):
    with open(FREE_TRIALS_FILE, 'w', encoding='utf-8') as f:
        json.dump(data, f, indent=4, ensure_ascii=False)

def create_server_from_package(username, password, package_id):
    """Create server based on package"""
    packages = load_yuta_packages()
    package = packages.get(package_id)
    
    print(f"[CREATE_SERVER] Username: {username}, Package: {package_id}, Package Found: {package is not None}")
    
    if not package:
        return None, 'Package not found'
    
    if not package.get('active', True):
        return None, 'Package is not active'
    
    users = load_users()
    
    if username in users:
        existing_servers = users[username].get('servers', [])
        if len(existing_servers) >= package['server_limit']:
            return None, f'Server limit reached! Max {package["server_limit"]} servers allowed.'
    
    server_id = str(uuid.uuid4())[:8]
    expiry_date = datetime.now() + timedelta(days=package['days'])
    
    create_default_files(get_server_dir(server_id))
    
    host = request.host
    is_local = host.startswith('localhost') or host.startswith('127.0.0.1') or host.startswith('192.168')
    scheme = 'http' if is_local else 'https'
    full_url = f"{scheme}://{host}/{server_id}/login"
    
    new_server = {
        'server_id': server_id,
        'login_url': f"/{server_id}/login",
        'dashboard_url': f"/{server_id}/home",
        'full_link': full_url,
        'type': 'python',
        'ram': package['ram'],
        'disk': package['disk'],
        'status': 'stopped',
        'pid': None,
        'created': str(datetime.now()),
        'expiry': str(expiry_date),
        'main_file': 'main.py',
        'requirements_file': 'requirements.txt',
        'cpu_limit': package['cpu_limit'],
        'rate_limit_exceeded': False,
        'stopped_by_user': False,
        'package': package_id
    }
    
    if username not in users:
        users[username] = {'password': password, 'role': 'user', 'servers': [new_server]}
        print(f"[CREATE_SERVER] New user created: {username}")
    else:
        if 'servers' not in users[username]:
            users[username]['servers'] = []
        users[username]['servers'].append(new_server)
        print(f"[CREATE_SERVER] Server added to existing user: {username}, Total servers: {len(users[username]['servers'])}")
    
    save_users(users)
    print(f"[CREATE_SERVER] Users saved successfully!")
    
    return {
        'server_id': server_id,
        'username': username,
        'login_url': new_server['login_url'],
        'full_url': new_server['full_link']
    }, None

# ============================================
# Rate Limiter
# ============================================

class RateLimiter:
    def check_rate(self, server_id, limit_percent):
        if server_id not in CPU_HISTORY:
            CPU_HISTORY[server_id] = []
        users = load_users()
        server = None
        for uname, data in users.items():
            if uname == 'admin': continue
            servers = data.get('servers', [])
            if not isinstance(servers, list): continue
            for s in servers:
                if isinstance(s, dict) and s.get('server_id') == server_id:
                    server = s
                    break
        if not server or server.get('status') != 'running':
            return False, 0
        pid = server.get('pid')
        if not pid: return False, 0
        try:
            proc = psutil.Process(pid)
            cpu = proc.cpu_percent(interval=1)
            now = time.time()
            CPU_HISTORY[server_id].append({'time': now, 'cpu': cpu})
            CPU_HISTORY[server_id] = [h for h in CPU_HISTORY[server_id] if now - h['time'] < 30]
            recent = [h['cpu'] for h in CPU_HISTORY[server_id] if now - h['time'] < 10]
            if recent:
                avg_cpu = sum(recent) / len(recent)
                if avg_cpu > limit_percent:
                    return True, avg_cpu
        except: pass
        return False, 0

rate_limiter = RateLimiter()

# ============================================
# Auto-Restart
# ============================================

def should_auto_restart(server_id):
    if server_id not in CRASH_COUNT:
        CRASH_COUNT[server_id] = {'count': 0, 'last_crash': time.time()}
    crash_info = CRASH_COUNT[server_id]
    if time.time() - crash_info['last_crash'] < 60:
        if crash_info['count'] >= 3:
            return False
    else:
        crash_info['count'] = 0
    crash_info['count'] += 1
    crash_info['last_crash'] = time.time()
    return True

# ============================================
# Helpers
# ============================================

def generate_random_password(length=10):
    chars = string.ascii_letters + string.digits
    return ''.join(random.choices(chars, k=length))

def load_users():
    if not os.path.exists(USERS_FILE):
        default = {"admin": {"password": "yuta_005", "role": "admin"}}
        save_users(default)
        return default
    with open(USERS_FILE, 'r', encoding='utf-8') as f:
        data = json.load(f)
    if 'admin' not in data:
        data['admin'] = {"password": "yuta_005", "role": "admin"}
        save_users(data)
    return data

def save_users(data):
    with open(USERS_FILE, 'w', encoding='utf-8') as f:
        json.dump(data, f, indent=4, ensure_ascii=False)

def get_server_dir(server_id):
    server_dir = os.path.join(BOTS_DIR, server_id)
    os.makedirs(server_dir, exist_ok=True)
    return server_dir

def check_server_valid(server_id):
    users = load_users()
    for uname, data in users.items():
        if uname == 'admin': continue
        servers = data.get('servers', [])
        if not isinstance(servers, list): continue
        for s in servers:
            if isinstance(s, dict) and s.get('server_id') == server_id:
                expiry = s.get('expiry', '')
                if expiry:
                    try:
                        exp_date = datetime.strptime(expiry, '%Y-%m-%d %H:%M:%S.%f')
                        if datetime.now() > exp_date:
                            return False, "expired"
                    except: pass
                return True, s
    return False, "deleted"

def get_server_by_id(server_id):
    users = load_users()
    for uname, data in users.items():
        if uname == 'admin': continue
        servers = data.get('servers', [])
        if not isinstance(servers, list): continue
        for s in servers:
            if isinstance(s, dict) and s.get('server_id') == server_id:
                return s, uname
    return None, None

def create_default_files(server_dir):
    main_py = os.path.join(server_dir, 'main.py')
    if not os.path.exists(main_py):
        with open(main_py, 'w', encoding='utf-8') as f:
            f.write('''# YUTA CLOUD HOSTING - Default Bot
import time

print("=" * 40)
print("Bot is running on YUTA CLOUD HOSTING")
print("Server is ready!")
print("=" * 40)

counter = 0
while True:
    counter += 1
    print(f"[{time.strftime('%H:%M:%S')}] Heartbeat #{counter} | Server active")
    time.sleep(10)
''')
    
    req_file = os.path.join(server_dir, 'requirements.txt')
    if not os.path.exists(req_file):
        with open(req_file, 'w', encoding='utf-8') as f:
            f.write('# Add your pip packages here\n')

# ============================================
# Bot Runner
# ============================================

def run_bot(server_id, main_file='main.py', requirements_file='requirements.txt'):
    server_dir = get_server_dir(server_id)
    main_path = os.path.join(server_dir, main_file)
    log_file = os.path.join(server_dir, 'output.log')
    python_exe = sys.executable
    
    def log(msg):
        try:
            with open(log_file, 'a', encoding='utf-8') as f:
                f.write(f"{msg}\n")
                f.flush()
        except: pass
    
    if not os.path.exists(main_path):
        return None, f"ERROR: {main_file} not found!"
    
    if os.path.exists(log_file):
        try: os.remove(log_file)
        except: open(log_file, 'w').close()
    
    ts = lambda: datetime.now().strftime('%I:%M:%S %p')
    
    server, _ = get_server_by_id(server_id)
    cpu_limit = server.get('cpu_limit', 80) if server else 80
    log(f"[{ts()}] Checking rate limit...")
    log(f"[{ts()}] Rate limit: {cpu_limit}%")
    log("")
    
    if requirements_file and requirements_file.strip():
        req_path = os.path.join(server_dir, requirements_file.strip())
        log(f"[{ts()}] Run: pip install -r {requirements_file}")
        log("")
        
        if os.path.exists(req_path):
            with open(req_path, 'r', encoding='utf-8') as f:
                content = f.read().strip()
            
            lines = [l.strip() for l in content.split('\n') if l.strip() and not l.strip().startswith('#')]
            
            if lines:
                try:
                    proc = subprocess.Popen(
                        [python_exe, '-m', 'pip', 'install', '-r', os.path.abspath(req_path), '--disable-pip-version-check'],
                        stdout=subprocess.PIPE, stderr=subprocess.STDOUT,
                        text=True, bufsize=1, universal_newlines=True,
                        creationflags=subprocess.CREATE_NO_WINDOW if sys.platform == 'win32' else 0
                    )
                    
                    for line in iter(proc.stdout.readline, ''):
                        if line.strip():
                            log(f"[{ts()}] {line.rstrip()}")
                    
                    proc.wait()
                    log("")
                    
                    if proc.returncode != 0:
                        log(f"[{ts()}] Some packages failed to install")
                    else:
                        log(f"[{ts()}] Requirements installation complete!")
                except Exception as e:
                    log(f"[{ts()}] pip error: {str(e)}")
            else:
                log(f"[{ts()}] {requirements_file} is empty, skipping...")
        else:
            log(f"[{ts()}] {requirements_file} not found, skipping...")
    else:
        log(f"[{ts()}] No requirements file set, skipping...")
    
    log("")
    log(f"[{ts()}] Run: python {main_file}")
    log(f"[{ts()}] Python {sys.version.split()[0]}")
    log("")
    
    try:
        main_path_abs = os.path.abspath(main_path)
        env = os.environ.copy()
        env['PYTHONIOENCODING'] = 'utf-8'
        env['PYTHONUNBUFFERED'] = '1'
        
        proc = subprocess.Popen(
            [python_exe, main_path_abs],
            stdout=subprocess.PIPE, stderr=subprocess.STDOUT,
            cwd=server_dir,
            text=True, encoding='utf-8', errors='replace',
            bufsize=1, env=env, universal_newlines=True,
            creationflags=subprocess.CREATE_NO_WINDOW if sys.platform == 'win32' else 0
        )
        
        log(f"[{ts()}] Server marked as running")
        log(f"[{ts()}] PID: {proc.pid}")
        log("")
        
        def rate_monitor():
            while proc.poll() is None:
                time.sleep(5)
                exceeded, avg_cpu = rate_limiter.check_rate(server_id, cpu_limit)
                if exceeded:
                    log(f"[{datetime.now().strftime('%I:%M:%S %p')}] CPU Limit! {avg_cpu:.1f}% > {cpu_limit}%")
                    proc.terminate()
                    time.sleep(2)
                    if proc.poll() is None: proc.kill()
                    
                    users = load_users()
                    for uname, data in users.items():
                        if uname == 'admin': continue
                        servers = data.get('servers', [])
                        if not isinstance(servers, list): continue
                        for s in servers:
                            if isinstance(s, dict) and s.get('server_id') == server_id:
                                s['status'] = 'stopped'
                                s['pid'] = None
                                s['rate_limit_exceeded'] = True
                                s['stopped_by_user'] = False
                                save_users(users)
                                break
                    break
        
        threading.Thread(target=rate_monitor, daemon=True).start()
        
        def stream_output():
            try:
                with open(log_file, 'a', encoding='utf-8') as f:
                    for line in iter(proc.stdout.readline, ''):
                        if line:
                            line = line.rstrip('\n\r')
                            if line:
                                f.write(f"[{datetime.now().strftime('%I:%M:%S %p')}] {line}\n")
                                f.flush()
            except: pass
        
        threading.Thread(target=stream_output, daemon=True).start()
        
        return proc.pid, None
        
    except Exception as e:
        log(f"[{ts()}] Error: {str(e)}")
        return None, str(e)

def stop_bot_process(pid):
    try:
        if sys.platform == 'win32':
            subprocess.run(['taskkill', '/F', '/PID', str(pid)], capture_output=True)
        else:
            os.kill(pid, 15)
        return True
    except: return False

def monitor_bot(server_id, pid):
    while True:
        try:
            if sys.platform == 'win32':
                result = subprocess.run(['tasklist', '/FI', f'PID eq {pid}'], capture_output=True, text=True)
                if str(pid) not in result.stdout:
                    break
            else:
                try: os.kill(pid, 0)
                except: break
        except: break
        time.sleep(5)
    
    server, _ = get_server_by_id(server_id)
    if not server: return
    if server.get('stopped_by_user'): return
    if server.get('rate_limit_exceeded'): return
    
    if should_auto_restart(server_id):
        time.sleep(3)
        new_pid, error = run_bot(server_id, server.get('main_file', 'main.py'), 
                                 server.get('requirements_file', 'requirements.txt'))
        if new_pid:
            users = load_users()
            for uname, data in users.items():
                if uname == 'admin': continue
                servers = data.get('servers', [])
                if not isinstance(servers, list): continue
                for s in servers:
                    if isinstance(s, dict) and s.get('server_id') == server_id:
                        s['status'] = 'running'
                        s['pid'] = new_pid
                        s['started_at'] = str(datetime.now())
                        s['rate_limit_exceeded'] = False
                        s['stopped_by_user'] = False
                        save_users(users)
                        break
            threading.Thread(target=monitor_bot, args=(server_id, new_pid), daemon=True).start()
    else:
        users = load_users()
        for uname, data in users.items():
            if uname == 'admin': continue
            servers = data.get('servers', [])
            if not isinstance(servers, list): continue
            for s in servers:
                if isinstance(s, dict) and s.get('server_id') == server_id:
                    s['status'] = 'stopped'
                    s['pid'] = None
                    save_users(users)
                    return

def get_process_stats(pid):
    try:
        proc = psutil.Process(pid)
        cpu = proc.cpu_percent(interval=0.5)
        mem = proc.memory_info()
        ram = mem.rss / (1024 * 1024)
        return {
            'cpu_percent': round(cpu, 1),
            'ram_mb': round(ram, 1),
            'ram_display': f"{ram:.1f} MB" if ram < 1024 else f"{ram/1024:.1f} GB",
        }
    except:
        return {'cpu_percent': 0, 'ram_mb': 0, 'ram_display': '0 MB'}

def get_network_stats(psutil_pid):
    try:
        proc = psutil.Process(psutil_pid)
        io = proc.io_counters()
        if io:
            read_kb = io.read_bytes / 1024
            write_kb = io.write_bytes / 1024
            return format_bytes(read_kb), format_bytes(write_kb)
    except: pass
    return "0 KB", "0 KB"

def format_bytes(kb):
    if kb < 1024: return f"{kb:.1f} KB"
    mb = kb / 1024
    if mb < 1024: return f"{mb:.1f} MB"
    gb = mb / 1024
    return f"{gb:.2f} GB"

# ============================================
# Public API - Server Create
# ============================================
# ============================================
# Server Renew System
# ============================================

@app.route('/api/server/renew', methods=['POST'])
def api_renew_server():
    """Renew existing server"""
    data = request.get_json()
    server_id = data.get('server_id', '')
    package_id = data.get('package_id', '')
    
    # Find server
    server, username = get_server_by_id(server_id)
    if not server:
        return jsonify({'status': 'error', 'message': 'Server not found!'}), 404
    
    # Get package
    packages = load_yuta_packages()
    package = packages.get(package_id)
    if not package:
        return jsonify({'status': 'error', 'message': 'Package not found!'}), 400
    
    if package.get('is_free'):
        return jsonify({'status': 'error', 'message': 'Cannot renew with free package!'}), 400
    
    # Get user email
    users = load_users()
    user_data = users.get(username, {})
    user_email = user_data.get('email', '')
    
    # If no email in user data, try to get from session
    if not user_email and 'user' in session:
        session_user = users.get(session['user'], {})
        user_email = session_user.get('email', '')
    
    # Fallback email
    if not user_email:
        user_email = f"{username}@yutacloud.host"
    
    print(f"[RENEW] Username: {username}, Email: {user_email}")
    
    amount = package['price']
    
    # Create payment
    settings = load_yuta_settings()
    bohudur.set_api_key(settings.get('bohudur_api_key', ''))
    
    if not settings.get('bohudur_api_key'):
        return jsonify({'status': 'error', 'message': 'Payment gateway not configured!'}), 400
    
    invoice_id = f"YUTA-RENEW-{str(uuid.uuid4())[:8].upper()}"
    
    host = request.host_url.rstrip('/')
    redirect_url = f"{host}/renew/success"
    cancel_url = f"{host}/payment/cancel"
    webhook_url = f"{host}/api/renew/webhook/success"
    
    result = bohudur.create_payment(
        full_name=username,
        email=user_email,  # ✅ Email added
        amount=amount,
        order_id=invoice_id,
        user_id=username,
        redirect_url=redirect_url,
        cancel_url=cancel_url,
        webhook_url=webhook_url,
        metadata={'server_id': server_id, 'package_id': package_id, 'type': 'renew'}
    )
    
    print(f"[RENEW] Bohudur Result: {result}")
    
    if result['success']:
        invoices = load_yuta_invoices()
        invoices.append({
            'invoice_id': invoice_id,
            'transaction_id': result['transaction_id'],
            'username': username,
            'email': user_email,
            'package_id': package_id,
            'amount': amount,
            'status': 'pending',
            'created_at': str(datetime.now()),
            'type': 'renew',
            'server_id': server_id
        })
        save_yuta_invoices(invoices)
        
        return jsonify({
            'status': 'success',
            'payment_url': result['payment_url'],
            'invoice_id': invoice_id
        })
    
    return jsonify({'status': 'error', 'message': result.get('error', 'Payment failed!')}), 400


@app.route('/api/renew/webhook/success', methods=['POST', 'GET'])
def renew_webhook():
    """Renew payment webhook"""
    if request.method == 'POST':
        data = request.get_json(silent=True) or {}
    else:
        data = request.args.to_dict()
    
    transaction_id = data.get('transaction_id', '')
    print(f"[RENEW_WEBHOOK] Received: {data}")
    
    if transaction_id:
        invoices = load_yuta_invoices()
        for inv in invoices:
            if inv.get('transaction_id') == transaction_id and inv['status'] == 'pending' and inv.get('type') == 'renew':
                inv['status'] = 'paid'
                inv['paid_at'] = str(datetime.now())
                
                server_id = inv.get('server_id')
                package_id = inv.get('package_id')
                
                users = load_users()
                for uname, udata in users.items():
                    for s in udata.get('servers', []):
                        if s.get('server_id') == server_id:
                            packages = load_yuta_packages()
                            pkg = packages.get(package_id, {})
                            days = pkg.get('days', 30)
                            
                            # Extend expiry
                            current_expiry = s.get('expiry', str(datetime.now()))
                            try:
                                current_expiry_date = datetime.strptime(current_expiry, '%Y-%m-%d %H:%M:%S.%f')
                            except:
                                current_expiry_date = datetime.now()
                            
                            new_expiry = current_expiry_date + timedelta(days=days)
                            s['expiry'] = str(new_expiry)
                            s['package'] = package_id
                            s['ram'] = pkg.get('ram', s.get('ram'))
                            s['disk'] = pkg.get('disk', s.get('disk'))
                            s['cpu_limit'] = pkg.get('cpu_limit', s.get('cpu_limit'))
                            
                            save_users(users)
                            save_yuta_invoices(invoices)
                            
                            print(f"[RENEW_WEBHOOK] ✅ Server {server_id} renewed for {days} days!")
                            
                            return jsonify({'status': 'success', 'message': f'Server renewed for {days} days!'})
        
    return jsonify({'status': 'ignored'})


# ============================================
# Renew Success Page
# ============================================

@app.route('/renew/success')
def renew_success():
    """Renew success page - handles Bohudur redirect with paymentkey"""
    paymentkey = request.args.get('paymentkey', '')
    
    print(f"[RENEW_SUCCESS] Payment Key: {paymentkey}")
    
    if paymentkey:
        invoices = load_yuta_invoices()
        
        for inv in invoices:
            if inv.get('transaction_id') == paymentkey and inv['status'] == 'pending' and inv.get('type') == 'renew':
                inv['status'] = 'paid'
                inv['paid_at'] = str(datetime.now())
                
                server_id = inv.get('server_id', '')
                package_id = inv.get('package_id', '')
                
                users = load_users()
                for uname, udata in users.items():
                    for s in udata.get('servers', []):
                        if s.get('server_id') == server_id:
                            packages = load_yuta_packages()
                            pkg = packages.get(package_id, {})
                            days = pkg.get('days', 30)
                            
                            # Extend expiry
                            try:
                                current_expiry_date = datetime.strptime(s.get('expiry', str(datetime.now())), '%Y-%m-%d %H:%M:%S.%f')
                            except:
                                current_expiry_date = datetime.now()
                            
                            new_expiry = current_expiry_date + timedelta(days=days)
                            s['expiry'] = str(new_expiry)
                            s['package'] = package_id
                            s['ram'] = pkg.get('ram', s.get('ram', 'N/A'))
                            s['disk'] = pkg.get('disk', s.get('disk', 'N/A'))
                            s['cpu_limit'] = pkg.get('cpu_limit', s.get('cpu_limit', 80))
                            
                            save_users(users)
                            save_yuta_invoices(invoices)
                            
                            print(f"[RENEW_SUCCESS] ✅ Server {server_id} renewed! New expiry: {str(new_expiry)[:10]}")
                            
                            # ✅ PASSING ALL DATA TO TEMPLATE
                            return render_template('renew_success.html',
                                server_id=server_id,
                                new_expiry=str(new_expiry)[:10],
                                days=str(days),
                                amount=str(inv.get('amount', 0)),
                                transaction_id=paymentkey
                            )
        
        # If already paid
        for inv in invoices:
            if inv.get('transaction_id') == paymentkey and inv['status'] == 'paid':
                return render_template('renew_success.html',
                    server_id=inv.get('server_id', ''),
                    new_expiry='Already updated',
                    days='-',
                    amount=str(inv.get('amount', 0)),
                    already_paid=True
                )
    
    # Default - pass whatever we have
    return render_template('renew_success.html')


@app.route('/renew/success/')
def renew_success_slash():
    """Handle trailing slash"""
    paymentkey = request.args.get('paymentkey', '')
    if paymentkey:
        return redirect(url_for('renew_success', paymentkey=paymentkey))
    return redirect(url_for('renew_success'))

@app.route('/api/create', methods=['GET'])
def api_create_server():
    username = request.args.get('username', '').strip()
    password = request.args.get('password', '').strip()
    server_type = request.args.get('type', 'python').strip()
    ram = request.args.get('ram', '1GB').strip()
    disk = request.args.get('disk', '1GB').strip()
    cpu_limit = int(request.args.get('cpu', '30'))
    days = int(request.args.get('days', '3'))
    
    if not password:
        password = generate_random_password(10)
    
    if not username:
        username = f"YUTA{random.randint(10000, 99999)}"
    
    if len(username) < 3:
        return jsonify({'status': 'error', 'message': 'Username must be at least 3 characters!'}), 400
    
    if len(password) < 4:
        return jsonify({'status': 'error', 'message': 'Password must be at least 4 characters!'}), 400
    
    if cpu_limit < 10 or cpu_limit > 100:
        return jsonify({'status': 'error', 'message': 'CPU limit must be between 10 and 100!'}), 400
    
    if days < 1 or days > 365:
        return jsonify({'status': 'error', 'message': 'Days must be between 1 and 365!'}), 400
    
    users = load_users()
    
    if username in users:
        return jsonify({'status': 'error', 'message': f"Username '{username}' already exists!"}), 400
    
    server_id = str(uuid.uuid4())[:8]
    expiry_date = datetime.now() + timedelta(days=days)
    
    create_default_files(get_server_dir(server_id))
    
    host = request.host
    is_local = host.startswith('localhost') or host.startswith('127.0.0.1') or host.startswith('192.168')
    scheme = 'http' if is_local else 'https'
    full_url = f"{scheme}://{host}/{server_id}/login"
    
    new_server = {
        'server_id': server_id,
        'login_url': f"/{server_id}/login",
        'dashboard_url': f"/{server_id}/home",
        'full_link': full_url,
        'type': server_type,
        'ram': ram, 'disk': disk,
        'status': 'stopped', 'pid': None,
        'created': str(datetime.now()),
        'expiry': str(expiry_date),
        'main_file': 'main.py',
        'requirements_file': 'requirements.txt',
        'cpu_limit': cpu_limit,
        'rate_limit_exceeded': False,
        'stopped_by_user': False
    }
    
    users[username] = {'password': password, 'role': 'user', 'servers': [new_server]}
    save_users(users)
    
    return jsonify({
        'status': 'success',
        'message': 'Panel created successfully!',
        'username': username,
        'password': password,
        'server_type': server_type,
        'ram': ram,
        'disk': disk,
        'cpu_limit': cpu_limit,
        'validity': f'{days} days',
        'expiry_date': expiry_date.strftime('%Y-%m-%d'),
        'full_url': full_url,
        'server_id': server_id
    }), 200

# ============================================
# Routes
# ============================================

@app.route('/')
def index():
    return render_template('landing.html')

@app.route('/landing')
def landing():
    return render_template('landing.html')

@app.route('/pricing')
def pricing_page():
    """Pricing page for users to view packages"""
    packages = load_yuta_packages()
    settings = load_yuta_settings()
    return render_template('pricing.html', packages=packages, settings=settings)

@app.route('/checkout/<package_id>')
def checkout_page(package_id):
    """Checkout page"""
    packages = load_yuta_packages()
    package = packages.get(package_id)
    if not package:
        return redirect(url_for('pricing_page'))
    settings = load_yuta_settings()
    return render_template('checkout.html', package=package, settings=settings)

# ============================================
# Sign In / Sign Up Pages (NEW - Auto redirect if logged in)
# ============================================

@app.route('/signin')
def signin_page():
    """User Sign In Page - Redirect if already logged in"""
    if 'user' in session and session.get('role') == 'user':
        return redirect(url_for('user_dashboard'))
    return render_template('signin.html')

@app.route('/signup')
def signup_page():
    """User Sign Up Page"""
    return render_template('signup.html')

# ============================================
# Login / Server Login
# ============================================

@app.route('/login', methods=['GET', 'POST'])
def login():
    if request.method == 'POST':
        username = request.form.get('username', '')
        password = request.form.get('password', '')
        users = load_users()
        if username == 'admin' and password == users.get('admin', {}).get('password'):
            session.permanent = True
            session['user'] = 'admin'
            session['role'] = 'admin'
            return redirect(url_for('admin_dashboard'))
        return render_template('login.html', error="Invalid credentials!")
    return render_template('login.html', error=None)

@app.route('/<server_id>/login', methods=['GET', 'POST'])
def server_login(server_id):
    valid, result = check_server_valid(server_id)
    if not valid:
        return render_template('error.html', error_type=result if result else "deleted", server_link=server_id)
    
    if request.method == 'POST':
        username = request.form.get('username', '')
        password = request.form.get('password', '')
        users = load_users()
        for uname, data in users.items():
            if uname == 'admin': continue
            servers = data.get('servers', [])
            if not isinstance(servers, list): continue
            for s in servers:
                if isinstance(s, dict) and s.get('server_id') == server_id:
                    if username == uname and password == data.get('password'):
                        session.permanent = True
                        session['user'] = uname
                        session['role'] = 'user'
                        session['current_server_id'] = server_id
                        return redirect(url_for('server_home', server_id=server_id))
                    else:
                        return render_template('login.html', error="Invalid credentials!")
        return render_template('login.html', error="Invalid login!")
    return render_template('login.html', error=None)

@app.route('/<server_id>/home')
def server_home(server_id):
    if 'user' not in session or session.get('role') != 'user':
        return redirect(url_for('server_login', server_id=server_id))
    if session.get('current_server_id') != server_id:
        session.clear()
        return redirect(url_for('server_login', server_id=server_id))
    
    valid, result = check_server_valid(server_id)
    if not valid:
        session.clear()
        return render_template('error.html', error_type=result if result else "deleted", server_link=server_id)
    
    return render_template('home.html', username=session['user'], current_server=result)

@app.route('/logout')
def logout():
    """Logout - Clear session completely"""
    session.clear()
    response = redirect(url_for('signin_page'))
    response.set_cookie('session', '', expires=0)
    return response

# ============================================
# User Account System
# ============================================

@app.route('/user/register', methods=['POST'])
def user_register():
    """User registration"""
    data = request.get_json()
    username = data.get('username', '').strip()
    password = data.get('password', '').strip()
    email = data.get('email', '').strip()
    
    if len(username) < 3:
        return jsonify({'status': 'error', 'message': 'Username must be at least 3 characters!'}), 400
    if len(password) < 4:
        return jsonify({'status': 'error', 'message': 'Password must be at least 4 characters!'}), 400
    
    users = load_users()
    
    if username in users:
        return jsonify({'status': 'error', 'message': 'Username already exists!'}), 400
    
    users[username] = {
        'password': password,
        'role': 'user',
        'email': email,
        'servers': [],
        'created_at': str(datetime.now()),
        'total_spent': 0
    }
    save_users(users)
    
    return jsonify({'status': 'success', 'message': 'Account created successfully!'})

@app.route('/user/login', methods=['POST'])
def user_login():
    """User login - Persistent session"""
    data = request.get_json()
    username = data.get('username', '').strip()
    password = data.get('password', '').strip()
    remember_me = data.get('remember_me', True)
    
    users = load_users()
    
    if username in users and users[username].get('password') == password:
        if users[username].get('role') == 'admin':
            return jsonify({'status': 'error', 'message': 'Please use admin login!'}), 400
        
        session.permanent = True
        session['user'] = username
        session['role'] = 'user'
        session['user_logged_in'] = True
        
        return jsonify({
            'status': 'success',
            'message': 'Login successful!',
            'username': username,
            'redirect': '/user/dashboard'
        })
    
    return jsonify({'status': 'error', 'message': 'Invalid credentials!'}), 401

@app.route('/user/dashboard')
def user_dashboard():
    """User dashboard - Persistent session"""
    if 'user' not in session or session.get('role') != 'user':
        return redirect(url_for('signin_page'))
    
    username = session['user']
    
    # Refresh session on each visit
    session.permanent = True
    session.modified = True
    
    users = load_users()
    user_data = users.get(username, {})
    servers = user_data.get('servers', [])
    
    print(f"[DASHBOARD] User: {username}, Servers: {len(servers)}")
    for s in servers:
        print(f"[DASHBOARD] Server: {s.get('server_id')}, Status: {s.get('status')}, Package: {s.get('package')}")
    
    packages = load_yuta_packages()
    invoices = load_yuta_invoices()
    user_invoices = [inv for inv in invoices if inv.get('username') == username]
    
    return render_template('user_dashboard.html', 
                         username=username, 
                         user_data=user_data, 
                         servers=servers,
                         packages=packages,
                         invoices=user_invoices)

@app.route('/user/dashboard/data')
def user_dashboard_data():
    """User dashboard data API - JSON format"""
    if 'user' not in session or session.get('role') != 'user':
        return jsonify({'status': 'error', 'message': 'Not logged in'}), 401
    
    username = session['user']
    users = load_users()
    user_data = users.get(username, {})
    servers = user_data.get('servers', [])
    
    print(f"[DASHBOARD_API] User: {username}, Servers count: {len(servers)}")
    for s in servers:
        print(f"[DASHBOARD_API] Server: {s.get('server_id')}, Status: {s.get('status')}, Package: {s.get('package', 'N/A')}")
    
    invoices = load_yuta_invoices()
    user_invoices = [inv for inv in invoices if inv.get('username') == username]
    
    return jsonify({
        'status': 'success',
        'username': username,
        'servers': servers,
        'invoices': user_invoices
    })

# ============================================
# Payment API
# ============================================

@app.route('/api/payment/create', methods=['POST'])
def api_create_payment():
    """Create payment for package"""
    data = request.get_json()
    
    package_id = data.get('package_id', '')
    username = data.get('username', '')
    email = data.get('email', '')
    
    packages = load_yuta_packages()
    package = packages.get(package_id)
    
    if not package:
        return jsonify({'status': 'error', 'message': 'Package not found!'}), 400
    
    if not package.get('active', True):
        return jsonify({'status': 'error', 'message': 'Package is not active!'}), 400
    
    # Free trial check
    if package.get('is_free'):
        settings = load_yuta_settings()
        if settings.get('allow_free_only_once', True):
            free_trials = load_yuta_free_trials()
            if username in free_trials:
                return jsonify({'status': 'error', 'message': 'You already used your free trial! Only one free trial allowed.'}), 400
            
            free_trials[username] = {
                'used_at': str(datetime.now()),
                'package': package_id,
                'ip': request.remote_addr
            }
            save_yuta_free_trials(free_trials)
        
        # Create free server
        password = data.get('password', generate_random_password(10))
        result, error = create_server_from_package(username, password, package_id)
        
        print(f"[FREE_TRIAL] Result: {result}, Error: {error}")
        
        if result:
            return jsonify({
                'status': 'success',
                'message': 'Free server created successfully!',
                'server_id': result['server_id'],
                'login_url': result['login_url'],
                'username': username,
                'password': password
            })
        else:
            return jsonify({'status': 'error', 'message': error}), 400
    
    # Paid payment
    settings = load_yuta_settings()
    bohudur.set_api_key(settings.get('bohudur_api_key', ''))
    
    if not settings.get('bohudur_api_key'):
        return jsonify({'status': 'error', 'message': 'Payment gateway not configured! Contact admin.'}), 400
    
    invoice_id = f"YUTA-{str(uuid.uuid4())[:8].upper()}"
    amount = package['price']
    
    host = request.host_url.rstrip('/')
    redirect_url = f"{host}/payment/success"
    cancel_url = f"{host}/payment/cancel"
    webhook_url = f"{host}/api/payment/webhook/success"
    
    result = bohudur.create_payment(
        full_name=username,
        email=email or f"{username}@yutahost.com",
        amount=amount,
        order_id=invoice_id,
        user_id=username,
        redirect_url=redirect_url,
        cancel_url=cancel_url,
        webhook_url=webhook_url,
        metadata={'package_id': package_id}
    )
    
    print(f"[PAYMENT_CREATE] Bohudur Result: {result}")
    
    if result['success']:
        transaction_id = result.get('transaction_id', '')
        
        invoices = load_yuta_invoices()
        invoices.append({
            'invoice_id': invoice_id,
            'transaction_id': transaction_id,
            'username': username,
            'email': email,
            'package_id': package_id,
            'amount': amount,
            'status': 'pending',
            'created_at': str(datetime.now()),
            'paid_at': None,
            'server_created': False
        })
        save_yuta_invoices(invoices)
        
        print(f"[PAYMENT_CREATE] Invoice saved. Transaction ID: {transaction_id}")
        
        return jsonify({
            'status': 'success',
            'payment_url': result['payment_url'],
            'invoice_id': invoice_id,
            'transaction_id': transaction_id,
            'amount': amount
        })
    else:
        return jsonify({'status': 'error', 'message': result.get('error', 'Payment creation failed!')}), 400

@app.route('/api/payment/webhook/success', methods=['POST', 'GET'])
def payment_webhook():
    """Payment success webhook - Auto create server"""
    if request.method == 'POST':
        data = request.get_json(silent=True) or {}
    else:
        data = request.args.to_dict()
    
    transaction_id = data.get('transaction_id', '')
    print(f"[WEBHOOK] Received: {data}")
    
    if transaction_id:
        invoices = load_yuta_invoices()
        for inv in invoices:
            if inv.get('transaction_id') == transaction_id and inv['status'] == 'pending':
                inv['status'] = 'paid'
                inv['paid_at'] = str(datetime.now())
                
                password = generate_random_password(10)
                result, error = create_server_from_package(inv['username'], password, inv['package_id'])
                
                print(f"[WEBHOOK] Auto Server Result: {result}, Error: {error}")
                
                if result:
                    inv['server_created'] = True
                    inv['server_id'] = result['server_id']
                    print(f"[WEBHOOK] ✅ Server auto-created: {result['server_id']}")
                else:
                    print(f"[WEBHOOK] ❌ Server creation failed: {error}")
                
                save_yuta_invoices(invoices)
                
                users = load_users()
                if inv['username'] in users:
                    users[inv['username']]['total_spent'] = users[inv['username']].get('total_spent', 0) + inv['amount']
                    if 'email' not in users[inv['username']] or not users[inv['username']].get('email'):
                        users[inv['username']]['email'] = inv.get('email', '')
                    save_users(users)
                
                return jsonify({'status': 'success', 'message': 'Payment processed and server created!'})
    
    return jsonify({'status': 'ignored'})

# ============================================
# Payment Success - Auto Server Create
# ============================================

@app.route('/payment/success')
def payment_success():
    """Payment success page - Auto create server"""
    paymentkey = request.args.get('paymentkey', '')
    
    print(f"[PAYMENT_SUCCESS] Full URL: {request.url}")
    print(f"[PAYMENT_SUCCESS] Payment Key: {paymentkey}")
    print(f"[PAYMENT_SUCCESS] All args: {request.args}")
    
    if paymentkey:
        invoices = load_yuta_invoices()
        
        found = False
        for inv in invoices:
            print(f"[PAYMENT_SUCCESS] Checking invoice: {inv.get('invoice_id')}, Transaction: {inv.get('transaction_id')}, Status: {inv.get('status')}")
            
            if inv.get('transaction_id') == paymentkey:
                found = True
                print(f"[PAYMENT_SUCCESS] ✅ Invoice matched: {inv['invoice_id']}")
                
                if inv['status'] == 'pending':
                    # Auto mark paid
                    inv['status'] = 'paid'
                    inv['paid_at'] = str(datetime.now())
                    
                    # Auto create server
                    password = generate_random_password(10)
                    result, error = create_server_from_package(inv['username'], password, inv['package_id'])
                    
                    print(f"[PAYMENT_SUCCESS] Server create result: {result}, Error: {error}")
                    
                    if result:
                        inv['server_created'] = True
                        inv['server_id'] = result['server_id']
                        save_yuta_invoices(invoices)
                        
                        # Update user
                        users = load_users()
                        if inv['username'] in users:
                            users[inv['username']]['total_spent'] = users[inv['username']].get('total_spent', 0) + inv['amount']
                            if not users[inv['username']].get('email'):
                                users[inv['username']]['email'] = inv.get('email', '')
                            save_users(users)
                            print(f"[PAYMENT_SUCCESS] ✅ User updated: {inv['username']}")
                        
                        packages = load_yuta_packages()
                        pkg = packages.get(inv['package_id'], {})
                        
                        print(f"[PAYMENT_SUCCESS] ✅ Server auto-created: {result['server_id']} for user {inv['username']}")
                        
                        return render_template('payment_success.html',
                            invoice_id=inv['invoice_id'],
                            transaction_id=paymentkey,
                            username=inv['username'],
                            server_id=result['server_id'],
                            package_name=pkg.get('name', inv['package_id']),
                            amount=inv['amount'],
                            ram=pkg.get('ram', 'N/A'),
                            disk=pkg.get('disk', 'N/A'),
                            days=pkg.get('days', 30)
                        )
                    else:
                        print(f"[PAYMENT_SUCCESS] ❌ Server creation failed: {error}")
                        save_yuta_invoices(invoices)
                        return render_template('payment_success.html', error=f"Server creation failed: {error}")
                
                elif inv['status'] == 'paid':
                    print(f"[PAYMENT_SUCCESS] Already paid")
                    return render_template('payment_success.html',
                        invoice_id=inv['invoice_id'],
                        transaction_id=paymentkey,
                        username=inv['username'],
                        server_id=inv.get('server_id', ''),
                        package_name=inv['package_id'],
                        amount=inv['amount'],
                        already_paid=True
                    )
        
        if not found:
            print(f"[PAYMENT_SUCCESS] ❌ No invoice found for paymentkey: {paymentkey}")
    
    return render_template('payment_success.html')


@app.route('/payment/success/')
def payment_success_slash():
    """Handle trailing slash - IMPORTANT"""
    paymentkey = request.args.get('paymentkey', '')
    print(f"[PAYMENT_SUCCESS/] Trailing slash, paymentkey: {paymentkey}")
    if paymentkey:
        return redirect(url_for('payment_success', paymentkey=paymentkey))
    return redirect(url_for('payment_success'))


@app.route('/payment/cancel')
def payment_cancel():
    """Payment cancelled page"""
    paymentkey = request.args.get('paymentkey', '')
    print(f"[PAYMENT_CANCEL] Payment Key: {paymentkey}")
    
    # Mark invoice as cancelled if paymentkey exists
    if paymentkey:
        invoices = load_yuta_invoices()
        for inv in invoices:
            if inv.get('transaction_id') == paymentkey and inv['status'] == 'pending':
                inv['status'] = 'cancelled'
                inv['cancelled_at'] = str(datetime.now())
                save_yuta_invoices(invoices)
                print(f"[PAYMENT_CANCEL] Invoice {inv['invoice_id']} marked as cancelled")
                break
    
    return render_template('payment_cancel.html')


@app.route('/payment/cancel/')
def payment_cancel_slash():
    """Handle trailing slash"""
    paymentkey = request.args.get('paymentkey', '')
    if paymentkey:
        return redirect(url_for('payment_cancel', paymentkey=paymentkey))
    return redirect(url_for('payment_cancel'))

# ============================================
# Admin Panel
# ============================================

@app.route('/admin')
def admin_dashboard():
    if 'user' not in session or session.get('role') != 'admin':
        return redirect(url_for('login'))
    users = load_users()
    user_list = []
    total_servers = 0
    total_running = 0
    for uname, data in users.items():
        if uname == 'admin': continue
        servers = data.get('servers', [])
        if not isinstance(servers, list): servers = []
        running = sum(1 for s in servers if isinstance(s, dict) and s.get('status') == 'running')
        total_servers += len(servers)
        total_running += running
        user_list.append({
            'username': uname, 'password': data.get('password', ''),
            'servers': servers, 'server_count': len(servers), 'running_count': running
        })
    return render_template('admin.html', users=user_list, total_servers=total_servers, total_running=total_running)

# ============================================
# Admin - Package Management (CRUD)
# ============================================

@app.route('/admin/packages')
def admin_packages_page():
    """Admin package management page"""
    if 'user' not in session or session.get('role') != 'admin':
        return redirect(url_for('login'))
    
    packages = load_yuta_packages()
    settings = load_yuta_settings()
    invoices = load_yuta_invoices()
    free_trials = load_yuta_free_trials()
    
    total_revenue = sum(inv['amount'] for inv in invoices if inv['status'] == 'paid')
    total_orders = len(invoices)
    paid_orders = len([inv for inv in invoices if inv['status'] == 'paid'])
    pending_orders = len([inv for inv in invoices if inv['status'] == 'pending'])
    total_free_used = len(free_trials)
    
    stats = {
        'total_revenue': total_revenue,
        'total_orders': total_orders,
        'paid_orders': paid_orders,
        'pending_orders': pending_orders,
        'total_free_used': total_free_used
    }
    
    return render_template('admin_packages.html',
                         packages=packages,
                         settings=settings,
                         invoices=invoices[-50:],
                         stats=stats)

# ============================================
# Public Package List API (No Login Required)
# ============================================

@app.route('/api/packages/list')
def public_get_packages():
    """Get all active packages - Public API, no login needed"""
    packages = load_yuta_packages()
    
    # Only return active packages
    active_packages = {}
    for pkg_id, pkg in packages.items():
        if pkg.get('active', True):
            active_packages[pkg_id] = pkg
    
    return jsonify({'packages': active_packages})

@app.route('/admin/api/packages/create', methods=['POST'])
def admin_create_package():
    if 'user' not in session or session.get('role') != 'admin':
        return jsonify({'error': 'Unauthorized'}), 403
    data = request.get_json()
    package_id = data.get('id', '').strip().lower()
    if not package_id:
        return jsonify({'error': 'Package ID is required!'}), 400
    if package_id in ['free_trial']:
        return jsonify({'error': 'Cannot use reserved package ID!'}), 400
    packages = load_yuta_packages()
    if package_id in packages:
        return jsonify({'error': 'Package ID already exists!'}), 400
    packages[package_id] = {
        'id': package_id,
        'name': data.get('name', package_id.title()),
        'icon': data.get('icon', '📦'),
        'price': int(data.get('price', 0)),
        'ram': data.get('ram', '1GB'),
        'disk': data.get('disk', '5GB'),
        'cpu_limit': int(data.get('cpu_limit', 80)),
        'days': int(data.get('days', 30)),
        'server_limit': int(data.get('server_limit', 5)),
        'active': data.get('active', True),
        'is_free': data.get('is_free', False),
        'features': data.get('features', [])
    }
    save_yuta_packages(packages)
    return jsonify({'success': True, 'message': 'Package created successfully!', 'package': packages[package_id]})

@app.route('/admin/api/packages/update/<package_id>', methods=['PUT'])
def admin_update_package(package_id):
    if 'user' not in session or session.get('role') != 'admin':
        return jsonify({'error': 'Unauthorized'}), 403
    data = request.get_json()
    packages = load_yuta_packages()
    if package_id not in packages:
        return jsonify({'error': 'Package not found!'}), 404
    pkg = packages[package_id]
    if 'name' in data: pkg['name'] = data['name']
    if 'icon' in data: pkg['icon'] = data['icon']
    if 'price' in data: pkg['price'] = int(data['price'])
    if 'ram' in data: pkg['ram'] = data['ram']
    if 'disk' in data: pkg['disk'] = data['disk']
    if 'cpu_limit' in data: pkg['cpu_limit'] = int(data['cpu_limit'])
    if 'days' in data: pkg['days'] = int(data['days'])
    if 'server_limit' in data: pkg['server_limit'] = int(data['server_limit'])
    if 'active' in data: pkg['active'] = data['active']
    if 'is_free' in data: pkg['is_free'] = data['is_free']
    if 'features' in data: pkg['features'] = data['features']
    save_yuta_packages(packages)
    return jsonify({'success': True, 'message': 'Package updated successfully!', 'package': pkg})

@app.route('/admin/api/packages/delete/<package_id>', methods=['DELETE'])
def admin_delete_package(package_id):
    if 'user' not in session or session.get('role') != 'admin':
        return jsonify({'error': 'Unauthorized'}), 403
    if package_id == 'free_trial':
        return jsonify({'error': 'Cannot delete free trial package!'}), 400
    packages = load_yuta_packages()
    if package_id in packages:
        del packages[package_id]
        save_yuta_packages(packages)
        return jsonify({'success': True, 'message': 'Package deleted successfully!'})
    return jsonify({'error': 'Package not found!'}), 404

@app.route('/admin/api/packages/toggle/<package_id>', methods=['POST'])
def admin_toggle_package(package_id):
    if 'user' not in session or session.get('role') != 'admin':
        return jsonify({'error': 'Unauthorized'}), 403
    packages = load_yuta_packages()
    if package_id in packages:
        packages[package_id]['active'] = not packages[package_id].get('active', True)
        save_yuta_packages(packages)
        status = 'activated' if packages[package_id]['active'] else 'deactivated'
        return jsonify({'success': True, 'message': f'Package {status}!'})
    return jsonify({'error': 'Package not found!'}), 404

# ============================================
# Admin - Settings Management
# ============================================

@app.route('/admin/api/settings/get')
def admin_get_settings():
    if 'user' not in session or session.get('role') != 'admin':
        return jsonify({'error': 'Unauthorized'}), 403
    settings = load_yuta_settings()
    return jsonify({'settings': settings})

@app.route('/admin/api/settings/save', methods=['POST'])
def admin_save_settings():
    if 'user' not in session or session.get('role') != 'admin':
        return jsonify({'error': 'Unauthorized'}), 403
    data = request.get_json()
    settings = load_yuta_settings()
    updateable_keys = [
        'site_name', 'bohudur_api_key', 'auto_verify_payment',
        'currency', 'trial_days', 'trial_enabled', 'allow_free_only_once'
    ]
    for key in updateable_keys:
        if key in data:
            if key in ['auto_verify_payment', 'trial_enabled', 'allow_free_only_once']:
                settings[key] = bool(data[key])
            elif key == 'trial_days':
                settings[key] = int(data[key])
            else:
                settings[key] = data[key]
    save_yuta_settings(settings)
    if 'bohudur_api_key' in data:
        bohudur.set_api_key(data['bohudur_api_key'])
    return jsonify({'success': True, 'message': 'Settings saved successfully!'})

# ============================================
# Admin - Invoice Management
# ============================================

@app.route('/admin/api/invoices/list')
def admin_get_invoices():
    if 'user' not in session or session.get('role') != 'admin':
        return jsonify({'error': 'Unauthorized'}), 403
    invoices = load_yuta_invoices()
    status_filter = request.args.get('status', '')
    if status_filter:
        invoices = [inv for inv in invoices if inv.get('status') == status_filter]
    return jsonify({'invoices': invoices[-100:], 'total': len(invoices)})

@app.route('/admin/api/invoices/verify', methods=['POST'])
def admin_verify_invoice():
    """Manually verify invoice - Only for special cases"""
    if 'user' not in session or session.get('role') != 'admin':
        return jsonify({'error': 'Unauthorized'}), 403
    
    data = request.get_json()
    invoice_id = data.get('invoice_id', '')
    invoices = load_yuta_invoices()
    
    for inv in invoices:
        if inv['invoice_id'] == invoice_id and inv['status'] == 'pending':
            inv['status'] = 'paid'
            inv['paid_at'] = str(datetime.now())
            inv['verified_by'] = 'admin'
            
            password = generate_random_password(10)
            result, error = create_server_from_package(inv['username'], password, inv['package_id'])
            
            if result:
                inv['server_created'] = True
                inv['server_id'] = result['server_id']
                save_yuta_invoices(invoices)
                return jsonify({
                    'success': True, 
                    'message': 'Payment verified and server created!', 
                    'server_id': result['server_id']
                })
            else:
                return jsonify({'error': error}), 400
    
    return jsonify({'error': 'Invoice not found or already processed!'}), 404

@app.route('/admin/api/invoices/reject/<invoice_id>', methods=['POST'])
def admin_reject_invoice(invoice_id):
    if 'user' not in session or session.get('role') != 'admin':
        return jsonify({'error': 'Unauthorized'}), 403
    invoices = load_yuta_invoices()
    for inv in invoices:
        if inv['invoice_id'] == invoice_id:
            inv['status'] = 'cancelled'
            inv['cancelled_at'] = str(datetime.now())
            inv['cancelled_by'] = 'admin'
            save_yuta_invoices(invoices)
            return jsonify({'success': True, 'message': 'Invoice rejected!'})
    return jsonify({'error': 'Invoice not found!'}), 404

# ============================================
# Admin - Original Server Management
# ============================================

@app.route('/admin/create_server', methods=['POST'])
def create_server():
    if 'user' not in session or session.get('role') != 'admin':
        return jsonify({'error': 'Unauthorized'}), 403
    data = request.get_json()
    username = data.get('username', '')
    password = data.get('password', '')
    server_type = data.get('server_type', 'python')
    ram = data.get('ram', '512MB')
    disk = data.get('disk', '1GB')
    expiry_days = int(data.get('expiry_days', 30))
    cpu_limit = int(data.get('cpu_limit', 80))
    if not username or not password:
        return jsonify({'error': 'Required!'}), 400
    users = load_users()
    server_id = str(uuid.uuid4())[:8]
    expiry_date = datetime.now() + timedelta(days=expiry_days)
    create_default_files(get_server_dir(server_id))
    new_server = {
        'server_id': server_id, 'link': server_id,
        'login_url': f"/{server_id}/login",
        'dashboard_url': f"/{server_id}/home",
        'full_link': request.host_url.rstrip('/') + f"/{server_id}/home",
        'type': server_type, 'ram': ram, 'disk': disk,
        'status': 'stopped', 'pid': None,
        'created': str(datetime.now()), 'expiry': str(expiry_date),
        'main_file': 'main.py', 'requirements_file': 'requirements.txt',
        'cpu_limit': cpu_limit, 'rate_limit_exceeded': False, 'stopped_by_user': False
    }
    if username not in users:
        users[username] = {'password': password, 'role': 'user', 'servers': []}
    users[username]['servers'].append(new_server)
    save_users(users)
    return jsonify({
        'success': True, 'username': username, 'password': password,
        'login_url': new_server['login_url'],
        'hostname': new_server['full_link'],
        'server_id': server_id
    })

@app.route('/admin/set_rate_limit/<server_id>', methods=['POST'])
def set_rate_limit(server_id):
    if 'user' not in session or session.get('role') != 'admin':
        return jsonify({'error': 'Unauthorized'}), 403
    cpu_limit = int(request.get_json().get('cpu_limit', 80))
    users = load_users()
    for uname, udata in users.items():
        if uname == 'admin': continue
        servers = udata.get('servers', [])
        if not isinstance(servers, list): continue
        for s in servers:
            if isinstance(s, dict) and s.get('server_id') == server_id:
                s['cpu_limit'] = cpu_limit
                save_users(users)
                return jsonify({'success': True, 'cpu_limit': cpu_limit})
    return jsonify({'error': 'Not found'}), 404

@app.route('/admin/delete_server/<username>/<server_id>', methods=['POST'])
def delete_server(username, server_id):
    if 'user' not in session or session.get('role') != 'admin':
        return jsonify({'error': 'Unauthorized'}), 403
    users = load_users()
    if username in users:
        servers = users[username].get('servers', [])
        if not isinstance(servers, list): servers = []
        for s in servers:
            if isinstance(s, dict) and s.get('server_id') == server_id:
                if s.get('pid'): stop_bot_process(s['pid'])
                try: shutil.rmtree(get_server_dir(server_id))
                except: pass
                break
        users[username]['servers'] = [s for s in servers if isinstance(s, dict) and s.get('server_id') != server_id]
        if len(users[username]['servers']) == 0:
            del users[username]
        save_users(users)
    return jsonify({'success': True})

# ============================================
# Bot API
# ============================================

@app.route('/api/run/<server_id>', methods=['POST'])
def api_run(server_id):
    server, _ = get_server_by_id(server_id)
    if not server: return jsonify({'status': 'error', 'msg': 'Not found'})
    if server.get('status') == 'running': return jsonify({'status': 'error', 'msg': 'Already running!'})
    server['rate_limit_exceeded'] = False
    server['stopped_by_user'] = False
    pid, error = run_bot(server_id, server.get('main_file', 'main.py'), server.get('requirements_file', 'requirements.txt'))
    if pid:
        users = load_users()
        for uname, data in users.items():
            if uname == 'admin': continue
            servers = data.get('servers', [])
            if not isinstance(servers, list): continue
            for s in servers:
                if isinstance(s, dict) and s.get('server_id') == server_id:
                    s['status'] = 'running'
                    s['pid'] = pid
                    s['started_at'] = str(datetime.now())
                    save_users(users)
                    break
        threading.Thread(target=monitor_bot, args=(server_id, pid), daemon=True).start()
        return jsonify({'status': 'success', 'msg': 'Started!'})
    return jsonify({'status': 'error', 'msg': error or 'Failed'})

@app.route('/api/stop/<server_id>', methods=['POST'])
def api_stop(server_id):
    server, _ = get_server_by_id(server_id)
    if not server: return jsonify({'status': 'error', 'msg': 'Not found'})
    if server.get('pid'): stop_bot_process(server['pid'])
    users = load_users()
    for uname, data in users.items():
        if uname == 'admin': continue
        servers = data.get('servers', [])
        if not isinstance(servers, list): continue
        for s in servers:
            if isinstance(s, dict) and s.get('server_id') == server_id:
                s['status'] = 'stopped'
                s['pid'] = None
                s['stopped_by_user'] = True
                save_users(users)
                break
    log_file = os.path.join(get_server_dir(server_id), 'output.log')
    try:
        with open(log_file, 'a', encoding='utf-8') as f:
            f.write(f"\n[{datetime.now().strftime('%I:%M:%S %p')}] Server stopped by user\n")
    except: pass
    return jsonify({'status': 'success', 'msg': 'Stopped'})

@app.route('/api/logs/<server_id>')
def api_logs(server_id):
    log_file = os.path.join(get_server_dir(server_id), 'output.log')
    if os.path.exists(log_file):
        with open(log_file, 'r', encoding='utf-8') as f: logs = f.read()
    else: logs = ""
    return jsonify({'logs': logs})

@app.route('/api/clear_logs/<server_id>', methods=['POST'])
def api_clear_logs(server_id):
    log_file = os.path.join(get_server_dir(server_id), 'output.log')
    try:
        if os.path.exists(log_file):
            try: os.remove(log_file)
            except: open(log_file, 'w').close()
        return jsonify({'status': 'success', 'msg': 'Cleared'})
    except: return jsonify({'status': 'error'}), 500

@app.route('/api/command', methods=['POST'])
def api_command():
    data = request.get_json()
    cmd = data.get('cmd', '')
    server_id = data.get('server_id', '')
    log_file = os.path.join(get_server_dir(server_id), 'output.log')
    try:
        result = subprocess.run(cmd, shell=True, capture_output=True, text=True, cwd=get_server_dir(server_id), timeout=30,
                              creationflags=subprocess.CREATE_NO_WINDOW if sys.platform == 'win32' else 0)
        output = (result.stdout + result.stderr)[:2000]
        with open(log_file, 'a', encoding='utf-8') as f:
            f.write(f"[{datetime.now().strftime('%I:%M:%S %p')}] $ {cmd}\n{output}\n")
        return jsonify({'status': 'success', 'output': output})
    except: return jsonify({'status': 'error', 'msg': 'Timeout'})

@app.route('/api/stats/<server_id>')
def api_stats(server_id):
    server, _ = get_server_by_id(server_id)
    if not server:
        return jsonify({'cpu': '0%', 'ram': '0 MB', 'uptime': '0h', 'status': 'unknown', 'cpu_limit': 80, 'net_in': '0 KB', 'net_out': '0 KB'})
    uptime, cpu, ram, net_in, net_out = "0h 0m", "0%", "0 MB", "0 KB", "0 KB"
    if server.get('status') == 'running' and server.get('pid'):
        stats = get_process_stats(server['pid'])
        cpu = f"{stats['cpu_percent']}%"
        ram = stats['ram_display']
        net_in, net_out = get_network_stats(server['pid'])
    if server.get('status') == 'running' and server.get('started_at'):
        try:
            start = datetime.strptime(server['started_at'], '%Y-%m-%d %H:%M:%S.%f')
            diff = datetime.now() - start
            if diff.days > 0: uptime = f"{diff.days}d {diff.seconds//3600}h"
            else:
                h, m, s = diff.seconds // 3600, (diff.seconds % 3600) // 60, diff.seconds % 60
                uptime = f"{h}h {m}m {s}s"
        except: pass
    return jsonify({'cpu': cpu, 'ram': ram, 'uptime': uptime, 'net_in': net_in, 'net_out': net_out, 'cpu_limit': server.get('cpu_limit', 80), 'status': server.get('status', 'stopped')})

# ============================================
# Password Change
# ============================================

@app.route('/api/change_password/<server_id>', methods=['POST'])
def api_change_password(server_id):
    if 'user' not in session: return jsonify({'error': 'Please login first!'}), 403
    data = request.get_json()
    current_password = data.get('current_password', '')
    new_password = data.get('new_password', '')
    if not current_password or not new_password: return jsonify({'error': 'All fields are required!'})
    if len(new_password) < 4: return jsonify({'error': 'Password must be at least 4 characters!'})
    users = load_users()
    username = session.get('user')
    if username in users:
        if users[username].get('password') == current_password:
            users[username]['password'] = new_password
            save_users(users)
            return jsonify({'success': True, 'msg': 'Password changed!'})
        return jsonify({'error': 'Current password is incorrect!'})
    return jsonify({'error': 'User not found!'}), 404

# ============================================
# GitHub API
# ============================================

@app.route('/api/github/deploy/<server_id>', methods=['POST'])
def api_github_deploy(server_id):
    """Download GitHub repo without git - using Python requests"""
    data = request.get_json()
    repo_url = data.get('repo_url', '').strip()
    access_token = data.get('access_token', '').strip()
    is_private = data.get('is_private', False)
    if not repo_url:
        return jsonify({'status': 'error', 'msg': 'Repository URL is required!'}), 400
    server_dir = get_server_dir(server_id)
    log_file = os.path.join(server_dir, 'github_deploy.log')
    try:
        with open(log_file, 'w', encoding='utf-8') as f:
            f.write(f"[{datetime.now().strftime('%I:%M:%S %p')}] Starting GitHub deployment...\n")
            f.write(f"[{datetime.now().strftime('%I:%M:%S %p')}] Repository: {repo_url}\n")
            f.write(f"[{datetime.now().strftime('%I:%M:%S %p')}] Type: {'Private' if is_private else 'Public'}\n")
            f.write("─" * 40 + "\n")
    except: pass
    def deploy_thread():
        try:
            import requests
            import shutil
            def deploy_log(msg):
                try:
                    with open(log_file, 'a', encoding='utf-8') as f:
                        f.write(f"[{datetime.now().strftime('%I:%M:%S %p')}] {msg}\n")
                        f.flush()
                except: pass
            deploy_log("Preparing deployment...")
            clean_url = repo_url.replace('.git', '').rstrip('/')
            if 'github.com' not in clean_url:
                deploy_log("Error: Only GitHub URLs are supported!")
                return
            parts = clean_url.split('github.com/')[-1].split('/')
            if len(parts) < 2:
                deploy_log("Error: Invalid GitHub URL format!")
                return
            owner = parts[0]
            repo = parts[1]
            branch = 'main'
            if len(parts) > 3 and parts[2] == 'tree':
                branch = parts[3]
            deploy_log(f"Owner: {owner}")
            deploy_log(f"Repository: {repo}")
            deploy_log(f"Branch: {branch}")
            deploy_log(f"Downloading ZIP archive...")
            api_url = f"https://api.github.com/repos/{owner}/{repo}/zipball/{branch}"
            headers = {'Accept': 'application/vnd.github.v3+json'}
            if is_private and access_token:
                headers['Authorization'] = f'token {access_token}'
                deploy_log("Using access token for authentication")
            response = requests.get(api_url, headers=headers, stream=True, timeout=60)
            if response.status_code == 200:
                deploy_log("Repository downloaded successfully!")
                deploy_log("Extracting files...")
                temp_zip = os.path.join(server_dir, '_github_temp.zip')
                with open(temp_zip, 'wb') as f:
                    for chunk in response.iter_content(chunk_size=8192):
                        f.write(chunk)
                try:
                    with zipfile.ZipFile(temp_zip, 'r') as zf:
                        root_folder = zf.namelist()[0].split('/')[0]
                        for member in zf.namelist():
                            relative_path = '/'.join(member.split('/')[1:])
                            if not relative_path: continue
                            target_path = os.path.join(server_dir, relative_path)
                            if member.endswith('/'):
                                os.makedirs(target_path, exist_ok=True)
                            else:
                                os.makedirs(os.path.dirname(target_path), exist_ok=True)
                                with zf.open(member) as source, open(target_path, 'wb') as target:
                                    shutil.copyfileobj(source, target)
                                deploy_log(f"  {relative_path}")
                    deploy_log("")
                    deploy_log("Deployment completed successfully!")
                except Exception as e:
                    deploy_log(f"Extraction error: {str(e)}")
                finally:
                    try: os.remove(temp_zip)
                    except: pass
            elif response.status_code == 404:
                deploy_log("Error: Repository not found!")
            elif response.status_code == 401:
                deploy_log("Error: Authentication failed!")
            elif response.status_code == 403:
                deploy_log("Error: Rate limit exceeded or access denied!")
            else:
                deploy_log(f"Error: HTTP {response.status_code}")
        except Exception as e:
            try:
                with open(log_file, 'a', encoding='utf-8') as f:
                    f.write(f"[{datetime.now().strftime('%I:%M:%S %p')}] Error: {str(e)}\n")
            except: pass
    threading.Thread(target=deploy_thread, daemon=True).start()
    return jsonify({'status': 'success', 'msg': 'Deployment started! Check terminal for progress.'})

@app.route('/api/github/logs/<server_id>')
def api_github_logs(server_id):
    log_file = os.path.join(get_server_dir(server_id), 'github_deploy.log')
    if os.path.exists(log_file):
        try:
            with open(log_file, 'r', encoding='utf-8') as f: logs = f.read()
        except: logs = "> Ready for deployment..."
    else: logs = "> Ready for deployment..."
    return jsonify({'logs': logs})

@app.route('/api/github/clear_logs/<server_id>', methods=['POST'])
def api_github_clear_logs(server_id):
    log_file = os.path.join(get_server_dir(server_id), 'github_deploy.log')
    try:
        if os.path.exists(log_file): os.remove(log_file)
        return jsonify({'status': 'success'})
    except: return jsonify({'status': 'error'}), 500

# ============================================
# File API
# ============================================

@app.route('/api/files/<server_id>')
def api_files(server_id):
    folder = request.args.get('folder', '')
    server_dir = get_server_dir(server_id)
    if folder:
        server_dir = os.path.join(server_dir, folder)
        if not os.path.abspath(server_dir).startswith(os.path.abspath(get_server_dir(server_id))):
            return jsonify({'files': []})
    if not os.path.exists(server_dir): return jsonify({'files': []})
    files = []
    try:
        for item in os.listdir(server_dir):
            item_path = os.path.join(server_dir, item)
            files.append({'name': item, 'is_dir': os.path.isdir(item_path), 'size': os.path.getsize(item_path) if os.path.isfile(item_path) else 0, 'modified': datetime.fromtimestamp(os.path.getmtime(item_path)).strftime('%Y-%m-%d %H:%M')})
    except: pass
    return jsonify({'files': files})

@app.route('/api/file/<server_id>', methods=['GET'])
def api_get_file(server_id):
    filename = request.args.get('filename', '')
    filepath = os.path.join(get_server_dir(server_id), filename)
    if os.path.exists(filepath) and os.path.isfile(filepath):
        with open(filepath, 'r', encoding='utf-8') as f: return jsonify({'content': f.read()})
    return jsonify({'error': 'Not found'}), 404

@app.route('/api/file/<server_id>', methods=['POST'])
def api_save_file(server_id):
    data = request.get_json()
    filepath = os.path.join(get_server_dir(server_id), data.get('filename', ''))
    os.makedirs(os.path.dirname(filepath), exist_ok=True)
    with open(filepath, 'w', encoding='utf-8') as f: f.write(data.get('content', ''))
    return jsonify({'success': True})

@app.route('/api/file/<server_id>', methods=['DELETE'])
def api_delete_file(server_id):
    data = request.get_json()
    filepath = os.path.join(get_server_dir(server_id), data.get('filename', ''))
    if os.path.exists(filepath):
        if os.path.isdir(filepath): shutil.rmtree(filepath)
        else: os.remove(filepath)
    return jsonify({'success': True})

@app.route('/api/upload/<server_id>', methods=['POST'])
def api_upload(server_id):
    if 'file' not in request.files: return jsonify({'error': 'No file'}), 400
    folder = request.form.get('folder', '')
    server_dir = get_server_dir(server_id)
    if folder:
        server_dir = os.path.join(server_dir, folder)
        os.makedirs(server_dir, exist_ok=True)
    file = request.files['file']
    file.save(os.path.join(server_dir, file.filename))
    return jsonify({'success': True})

@app.route('/api/create_folder/<server_id>', methods=['POST'])
def api_create_folder(server_id):
    data = request.get_json()
    os.makedirs(os.path.join(get_server_dir(server_id), data.get('foldername', '')), exist_ok=True)
    return jsonify({'success': True})

@app.route('/api/rename/<server_id>', methods=['POST'])
def api_rename(server_id):
    d = request.get_json()
    server_dir = get_server_dir(server_id)
    old_path = os.path.join(server_dir, d.get('old_name', ''))
    new_path = os.path.join(server_dir, d.get('new_name', ''))
    if os.path.exists(old_path):
        os.rename(old_path, new_path)
        return jsonify({'success': True})
    return jsonify({'error': 'Not found'}), 404

@app.route('/api/unzip/<server_id>', methods=['POST'])
def api_unzip(server_id):
    data = request.get_json()
    zip_path = os.path.join(get_server_dir(server_id), data.get('filename', ''))
    if os.path.exists(zip_path) and zip_path.endswith('.zip'):
        try:
            with zipfile.ZipFile(zip_path, 'r') as zf: zf.extractall(os.path.dirname(zip_path))
            return jsonify({'status': 'success', 'msg': 'Extracted!'})
        except Exception as e: return jsonify({'status': 'error', 'msg': str(e)})
    return jsonify({'status': 'error', 'msg': 'Invalid zip'}), 400

@app.route('/api/get_startup/<server_id>')
def api_get_startup(server_id):
    server, _ = get_server_by_id(server_id)
    if server: return jsonify({'main_file': server.get('main_file', 'main.py'), 'requirements_file': server.get('requirements_file', 'requirements.txt')})
    return jsonify({'main_file': 'main.py', 'requirements_file': 'requirements.txt'})

@app.route('/api/set_startup/<server_id>', methods=['POST'])
def api_set_startup(server_id):
    d = request.get_json()
    users = load_users()
    for uname, udata in users.items():
        if uname == 'admin': continue
        servers = udata.get('servers', [])
        if not isinstance(servers, list): continue
        for s in servers:
            if isinstance(s, dict) and s.get('server_id') == server_id:
                s['main_file'] = d.get('main_file', 'main.py')
                s['requirements_file'] = d.get('requirements_file')
                save_users(users)
                return jsonify({'success': True})
    return jsonify({'error': 'Not found'}), 404

# ============================================
# Start
# ============================================

if __name__ == '__main__':
    settings = load_yuta_settings()
    if settings.get('bohudur_api_key'):
        bohudur.set_api_key(settings['bohudur_api_key'])
    
    print("\n" + "=" * 50)
    print("🚀 YUTA CLOUD HOSTING")
    print("=" * 50)
    print("📍 Landing: http://localhost:5000")
    print("📍 Sign In: http://localhost:5000/signin")
    print("📍 Sign Up: http://localhost:5000/signup")
    print("📍 Pricing: http://localhost:5000/pricing")
    print("📍 Admin: http://localhost:5000/login")
    print("📍 Admin Packages: http://localhost:5000/admin/packages")
    print("👤 admin / admin123")
    print("=" * 50 + "\n")
    app.run(debug=True, host='0.0.0.0', port=5000)