# bohudur_gateway.py

import requests
import json
from datetime import datetime

class BohudurGateway:
    def __init__(self, api_key=None):
        self.api_key = api_key
        self.base_url = "https://request.bohudur.one"
        
    def set_api_key(self, api_key):
        self.api_key = api_key
    
    def create_payment(self, full_name, email, amount, order_id, user_id, 
                       redirect_url, cancel_url, webhook_url, metadata=None):
        if not self.api_key:
            return {'success': False, 'error': 'API Key not set!'}
        
        payload = {
            "full_name": full_name,
            "email": email,
            "amount": int(amount),
            "return_type": "GET",
            "redirect_url": redirect_url,
            "cancel_url": cancel_url,
            "metadata": {
                "order_id": order_id,
                "user_id": user_id,
                "platform": "YUTA_CLOUD_HOSTING",
                **(metadata or {})
            },
            "webhook": {
                "success": webhook_url,
                "cancel": cancel_url
            }
        }
        
        try:
            response = requests.post(
                f"{self.base_url}/create/v2/",
                json=payload,
                headers={
                    "Content-Type": "application/json",
                    "AH-BOHUDUR-API-KEY": self.api_key
                },
                timeout=30
            )
            
            result = response.json()
            print(f"[BOHUDUR] Create Response: {result}")
            
            if response.status_code == 200 and result.get('status') == 'success':
                # paymentkey কে transaction_id হিসেবে ব্যবহার করো
                paymentkey = result.get('paymentkey', '')
                payment_url = result.get('payment_url', '')
                
                return {
                    'success': True,
                    'payment_url': payment_url,
                    'transaction_id': paymentkey,  # এইটা দিয়ে পরে ভেরিফাই করবে
                    'paymentkey': paymentkey,
                    'reference': paymentkey
                }
            else:
                return {
                    'success': False, 
                    'error': result.get('message', 'Payment creation failed'),
                    'raw_response': result
                }
                
        except Exception as e:
            return {'success': False, 'error': str(e)}
    
    def verify_payment(self, transaction_id):
        """Paymentkey দিয়ে পেমেন্ট ভেরিফাই"""
        if not self.api_key:
            return {'success': False, 'error': 'API Key not set!'}
        
        try:
            response = requests.post(
                f"{self.base_url}/verify/v2/",
                json={"transaction_id": transaction_id},
                headers={
                    "Content-Type": "application/json",
                    "AH-BOHUDUR-API-KEY": self.api_key
                },
                timeout=15
            )
            
            result = response.json()
            print(f"[BOHUDUR] Verify Response: {result}")
            
            if response.status_code == 200:
                return {
                    'success': True, 
                    'status': result.get('status', result.get('payment_status', 'unknown')), 
                    'data': result
                }
            else:
                return {
                    'success': False, 
                    'error': result.get('message', 'Verification failed'),
                    'raw_response': result
                }
                
        except Exception as e:
            return {'success': False, 'error': str(e)}
    
    def check_payment_status(self, paymentkey):
        """Paymentkey দিয়ে স্ট্যাটাস চেক (অল্টারনেটিভ)"""
        if not self.api_key:
            return {'success': False, 'error': 'API Key not set!'}
        
        try:
            # কিছু গেটওয়েতে আলাদা স্ট্যাটাস চেক URL থাকে
            response = requests.post(
                f"{self.base_url}/status/v2/",
                json={"paymentkey": paymentkey},
                headers={
                    "Content-Type": "application/json",
                    "AH-BOHUDUR-API-KEY": self.api_key
                },
                timeout=15
            )
            
            result = response.json()
            print(f"[BOHUDUR] Status Response: {result}")
            
            return {
                'success': True,
                'data': result
            }
        except Exception as e:
            return {'success': False, 'error': str(e)}

bohudur = BohudurGateway()